execute store result score #count shop run clear @s minecraft:potion[custom_data={nexoria_item:"heal_potion_1"}]
scoreboard players operation #gain shop = #count shop
scoreboard players set #price shop 40
scoreboard players operation #gain shop *= #price shop
scoreboard players operation @s Gold += #gain shop
execute if score #count shop matches 1.. run tellraw @s [{"text":"治癒のポーション IVを ","color":"green"},{"score":{"name":"#count","objective":"shop"}},{"text":" 個売却しました。（+"},{"score":{"name":"#gain","objective":"shop"}},{"text":"G）"}]
execute unless score #count shop matches 1.. run tellraw @s {"text":"治癒のポーション IVを持っていません。","color":"red"}
