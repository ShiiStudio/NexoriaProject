execute store result score #count shop run clear @s minecraft:bone[custom_data={nexoria_pet:"velmire_wolf"}]
scoreboard players operation #gain shop = #count shop
scoreboard players set #price shop 150
scoreboard players operation #gain shop *= #price shop
scoreboard players operation @s Gold += #gain shop
execute if score #count shop matches 1.. run tellraw @s [{"text":"Velmireウルフを ","color":"green"},{"score":{"name":"#count","objective":"shop"}},{"text":" 個売却しました。（+"},{"score":{"name":"#gain","objective":"shop"}},{"text":"G）"}]
execute unless score #count shop matches 1.. run tellraw @s {"text":"Velmireウルフを持っていません。","color":"red"}
